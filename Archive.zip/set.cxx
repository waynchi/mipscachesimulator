/* set.cxx
 * implementaiton of the set class for the cache simulator
 *
 * ECEN 4593, Fall 2010
 * Danny Gale, Chris Messick
 *
 * REVISION HISTORY:
 * 11/8/2010   Danny Gale  created
 *
 */

using namespace std;

// COMPILER INCLUDES
#include <iostream>

// PROJECT INCLUDES
#include "set.h"
#include "cacheline.h"
#include "defines.h"

set::set()
{
   cout << endl << "Error: Set associativity not defined" << endl;
   exit(ES_SET_ASSOCIATIVITY);
}

set::set(unsigned newAssoc)
{
   associativity = newAssoc;

   // create the array of cacheLines for each set.
   lines = new cacheLine[associativity];
}

set::~set()
{
   // remove the array
   delete [] lines;
}

void set::set_associativity(unsigned value)
{
   // remove the array
   delete [] lines;
   // update associativity
   associativity = value;
   // create new array with correct size
   lines = new cacheLine[associativity];
}

void set::update_LRU(cacheLine * mostRecent)
{
   // find any and all (should only be one) instances
   // of mostRecent in LRU
}
