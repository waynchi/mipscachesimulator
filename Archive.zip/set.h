/* set.h
 * header file for a set class
 * contains a number of cachelines depending on the associativity of the cache
 *
 * ECEN4593, Fall 2010
 * Danny Gale, Chris Messick
 *
 * REVISION HISTORY:
 * 11/8/2010   Danny Gale  created
 *
 */
#ifndef _SET_H_
#define _SET_H_

using namespace std;

// COMPILER INCLUDES
#include <list>

// PROJECT INCLUDES
#include "cacheline.h"
#include "cxxcache.h"

class set : public cache
{
   public:
      // CONSTRUCTORS AND DESTRUCTOR
      set();
      set(unsigned associativity);
      ~set();
   
      // CONSTANT MEMBER FUNCTIONS
      unsigned get_associativity() const { return associativity; }
      cacheLine * get_line(unsigned blockNum) const { return &lines[blockNum]; }// returns a pointer to the called-for block
      
      // MEMBER FUNCTIONS
      void set_associativity(unsigned value);	// need to re-size dynamic array of cacheLines
      void update_LRU (cacheLine * most_recent);

      // places the new block into the cache. returns a pointer to 
      // a cacheLine if one had to be evicted.
      // If a line was returned (and thus evicted) it MUST BE WRITTEN
      // BACK TO L2 and MAIN MEMORY
      cacheLine * put_line(cacheLine * newLine); 

   private:
      list<cacheLine *> LRU;
      unsigned associativity;
      cacheLine * lines;
};

#endif
